﻿using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Chrome;
using TestProject.PageObjects;
using Xunit.Abstractions;

namespace TestProject
{
    public class Tests : IDisposable
    {
        private readonly ITestOutputHelper _output;
        private readonly CustomWebDriver _driver;
        private readonly string _downloadDirectory;

        private static readonly string MainPageUrl = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json")
            .Build()["MainPageUrl"]!;

        public Tests(ITestOutputHelper output)
        {
            _output = output;

            _downloadDirectory = Path.Combine(Path.GetTempPath(), "epam_downloads_" + Guid.NewGuid());
            Directory.CreateDirectory(_downloadDirectory);

            var options = new ChromeOptions();
            options.AddUserProfilePreference("download.default_directory", _downloadDirectory);
            options.AddUserProfilePreference("download.prompt_for_download", false);
            options.AddUserProfilePreference("plugins.always_open_pdf_externally", true);
            options.AddUserProfilePreference("safebrowsing.enabled", true);

            var chromeDriver = new ChromeDriver(options);
            chromeDriver.Manage().Window.Maximize();

            _driver = new CustomWebDriver(chromeDriver, TimeSpan.FromSeconds(15));
        }

        public void Dispose()
        {
            _driver.Quit();

            if (Directory.Exists(_downloadDirectory))
            {
                try { Directory.Delete(_downloadDirectory, true); }
                catch { /* best effort cleanup */ }
            }
        }

        [Theory]
        [InlineData(".NET", "Republic of Lithuania")]
        [InlineData("Java", "Poland")]
        public void Task1_PositionSearchResultDescriptionContainsSearchKeyword(string searchKeyword, string searchCountry)
        {
            var mainPage = new MainPage(_driver, MainPageUrl);
            mainPage.Open();

            var jobPage = mainPage.GoToCareers().StartYourSearch();

            string descriptionText = jobPage
                .EnterSearchKeyword(searchKeyword)
                .SubmitSearch()
                .SelectCountry(searchCountry)
                .ToggleRemoteFilter()
                .ExpandFirstResult()
                .GetJobDescriptionText();

            _output.WriteLine($"Description text: {descriptionText}");

            Assert.True(
                descriptionText.Contains(searchKeyword, StringComparison.OrdinalIgnoreCase),
                $"Expected description to contain '{searchKeyword}' but it did not.");
        }

        [Theory]
        [InlineData("BLOCKCHAIN")]
        [InlineData("Cloud")]
        [InlineData("Automation")]
        public void Task2_GlobalSearchWithValidInputResultsContainSearchKeyword(string searchKeyword)
        {
            var mainPage = new MainPage(_driver, MainPageUrl);
            mainPage.Open();

            List<string> resultTitles = mainPage
                .OpenGlobalSearch()
                .EnterGlobalSearchKeyword(searchKeyword)
                .SubmitGlobalSearch()
                .GetGlobalSearchResultTitles();

            resultTitles.ForEach(title => _output.WriteLine(title));

            Assert.True(resultTitles.All(title => title.Contains(searchKeyword, StringComparison.OrdinalIgnoreCase)));
        }

        [Theory]
        [InlineData("Code-Of-Conduct_01_26.pdf")]
        public void Task3_CodeOfEthicalConductPdfDownloadsSuccessfully(string expectedFileName)
        {
            var mainPage = new MainPage(_driver, MainPageUrl);
            mainPage.Open();
            mainPage.ClickCodeOfEthicalConductPdfLink();

            string expectedFilePath = Path.Combine(_downloadDirectory, expectedFileName);
            bool downloaded = WaitForFileToBeDownloaded(expectedFilePath, TimeSpan.FromSeconds(30));

            Assert.True(downloaded, $"Expected file '{expectedFileName}' was not found in '{_downloadDirectory}'.");
        }

        [Theory]
        [InlineData(2)]
        [InlineData(3)]
        public void Task4_ArticleTitleMatchesCarouselTitle(int swipeCount)
        {
            var mainPage = new MainPage(_driver, MainPageUrl);
            mainPage.Open();

            var insightsPage = mainPage.GoToInsights();
            insightsPage.SwipeCarousel(swipeCount);

            string carouselArticleTitle = insightsPage.GetCurrentArticleTitle();
            _output.WriteLine($"Carousel article title: {carouselArticleTitle}");

            var articlePage = insightsPage.ClickReadMore();
            string articlePageTitle = articlePage.GetArticleTitle();
            _output.WriteLine($"Article page title: {articlePageTitle}");

            Assert.Equal(NormalizeWhitespace(carouselArticleTitle), NormalizeWhitespace(articlePageTitle), ignoreCase: true);
        }

        private static string NormalizeWhitespace(string text) =>
            string.Join(' ', text.Replace('\u00A0', ' ').Split(' ', StringSplitOptions.RemoveEmptyEntries)).Trim();

        private static bool WaitForFileToBeDownloaded(string filePath, TimeSpan timeout)
        {
            DateTime deadline = DateTime.UtcNow.Add(timeout);

            while (DateTime.UtcNow < deadline)
            {
                bool partialDownloadInProgress = File.Exists(filePath + ".crdownload") || File.Exists(filePath + ".tmp");

                if (File.Exists(filePath) && !partialDownloadInProgress)
                {
                    return true;
                }

                Thread.Sleep(500);
            }

            return false;
        }
    }
}
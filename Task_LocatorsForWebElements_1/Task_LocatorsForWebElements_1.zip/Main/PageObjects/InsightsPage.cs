﻿using OpenQA.Selenium;

namespace TestProject.PageObjects
{
    public class InsightsPage : BasePage
    {
        // The carousel is an Owl Carousel instance: it advances via clicks on the
        // arrow buttons (or drag), not via mouse-wheel scroll events.
        private readonly By _activeSlideLocator = By.CssSelector(".owl-item.active");
        private readonly By _activeSlideTitleLocator = By.CssSelector(".owl-item.active .text-ui-23");
        private readonly By _activeSlideReadMoreLocator = By.CssSelector(".owl-item.active .slider-cta-link");
        private readonly By _nextArrowLocator = By.CssSelector(".slider__right-arrow");

        public InsightsPage(CustomWebDriver driver) : base(driver) { }

        /// <summary>Advances the carousel forward the given number of times by clicking the next-slide arrow.</summary>
        public InsightsPage SwipeCarousel(int times)
        {
            for (int i = 0; i < times; i++)
            {
                Driver.ClickWhenReady(_nextArrowLocator);
                Driver.WaitUntil(d => d.FindElement(_activeSlideLocator).Displayed);
                Thread.Sleep(500);
            }

            return this;
        }

        public string GetCurrentArticleTitle() => Driver.GetText(_activeSlideTitleLocator);

        public ArticlePage ClickReadMore()
        {
            Driver.ClickWhenReady(_activeSlideReadMoreLocator);
            return new ArticlePage(Driver);
        }
    }
}
﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace TestProject.PageObjects
{
    public class JobPage : BasePage
    {
        private readonly By _searchByKeywordLocator = By.Name("search");
        private readonly By _countryDropdownLocator = By.CssSelector("[data-testid='country-dropdown'] .dropdown__control");
        private readonly By _countryInputLocator = By.CssSelector("input.dropdown__input");
        private readonly By _countryOptionLocator = By.CssSelector("div[class*='dropdown__option']");
        private readonly By _countryDropDownMenuLocator = By.ClassName("dropdown__menu");
        private readonly By _countryDropDownValueLocator = By.CssSelector("div[data-testid='dropdown-value']");
        private readonly By _remoteFilterCheckboxLocator = By.CssSelector("label[for*='checkbox-vacancy_type-Remote']");
        private readonly By _searchButtonLocator = By.XPath("//button[@name='submit_search_box_button']");
        private readonly By _expandItemButtonLocator = By.CssSelector("span[data-testid='accordion-section-header-icon-container']");
        private readonly By _jobDescriptionLocator = By.CssSelector("div[data-testid='categories-container']");

        public JobPage(CustomWebDriver driver) : base(driver) { }

        public JobPage EnterSearchKeyword(string keyword)
        {
            Driver.TypeText(_searchByKeywordLocator, keyword);
            return this;
        }

        public JobPage SubmitSearch()
        {
            Driver.ClickWhenReady(_searchButtonLocator);
            return this;
        }

        public JobPage SelectCountry(string country)
        {
            var dropdown = Driver.WaitUntilClickable(_countryDropdownLocator);
            Driver.ScrollIntoView(dropdown);

            // Dropdown re-renders right after scrolling into view; a short pause avoids
            // an ElementClickInterceptedException without closing the menu prematurely.
            Thread.Sleep(500);
            Driver.ClickSafe(_countryDropdownLocator);
            //dropdown.Click();

            Driver.WaitUntil((drv => drv.FindElement(_countryDropDownMenuLocator)));

            //Driver.WaitUntil(d => d.FindElements(_countryDropDownMenuLocator).Count > 0);

            /*
            _ignoreExceptionWait.Until(drv => drv.FindElements(_countryOptionLocator).FirstOrDefault(o => o.Text.Equals(searchCountry))).Click();

            _wait.Until(drv =>
            {
                IWebElement element = drv.FindElement(_countryDropDownValue);
                return element.Text.Equals(searchCountry) && element.Displayed && element.Enabled;
            });
            */



            Driver.TypeText(_countryInputLocator, country);
            //Driver.ClickSafe(_countryOptionLocator);



            Driver.WaitIgnoringStaleness(d =>
                d.FindElements(_countryOptionLocator).FirstOrDefault(o => o.Text.Equals(country))
            ).Click();
            

            Driver.WaitUntil(d =>
            {
                var value = d.FindElement(_countryDropDownValueLocator);
                return value.Text.Equals(country) && value.Displayed && value.Enabled;
            });

            return this;
        }

        public JobPage ToggleRemoteFilter()
        {


            var checkbox = Driver.WaitUntil(d =>
            {
                var element = d.FindElement(_remoteFilterCheckboxLocator);
                return element.Enabled ? element : null;
            });
            checkbox.Click();
            return this;
        }

        public JobPage ExpandFirstResult()
        {
            Driver.WaitUntil(d => d.FindElements(_expandItemButtonLocator).Count > 0);

            Driver.WaitIgnoringStaleness(d =>
            {
                var element = d.FindElement(_expandItemButtonLocator);
                if (element.Displayed && element.Enabled)
                {
                    element.Click();
                    return true;
                }
                return false;
            });

            return this;
        }

        public string GetJobDescriptionText() => Driver.GetText(_jobDescriptionLocator);
    }
}
